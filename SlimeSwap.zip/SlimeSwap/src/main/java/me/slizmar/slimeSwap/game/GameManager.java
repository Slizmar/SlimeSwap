package me.slizmar.slimeSwap.game;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

public class GameManager {

    private final JavaPlugin plugin;

    private int swapSeconds = 300;   // default 5 minutes
    private int playerCount = 2;     // 2, 3, or 4
    private boolean running = false;
    private final List<UUID> participants = new ArrayList<>();
    private BukkitTask tickTask;
    private int secondsLeft;

    public GameManager(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean setSwapSeconds(int seconds) {
        if (seconds < 10) return false;
        this.swapSeconds = seconds;
        return true;
    }

    public boolean setPlayerCount(int count) {
        if (count < 2 || count > 4) return false;
        this.playerCount = count;
        return true;
    }

    public int getSwapSeconds() { return swapSeconds; }
    public int getPlayerCount() { return playerCount; }
    public boolean isRunning()  { return running; }

    public String start() {
        if (running) return "A game is already running.";

        List<Player> online = new ArrayList<>(Bukkit.getOnlinePlayers());
        if (online.size() < playerCount) {
            return "Need " + playerCount + " online players, only " + online.size() + " present.";
        }

        participants.clear();
        for (int i = 0; i < playerCount; i++) {
            participants.add(online.get(i).getUniqueId());
        }

        running = true;
        secondsLeft = swapSeconds;

        broadcast(Component.text("Death Swap started! Swap in " + formatTime(swapSeconds) + ".",
                NamedTextColor.GREEN));

        tickTask = new BukkitRunnable() {
            @Override
            public void run() {
                tick();
            }
        }.runTaskTimer(plugin, 20L, 20L);

        return null;
    }

    public void stop(boolean announce) {
        if (!running) return;
        running = false;
        if (tickTask != null) {
            tickTask.cancel();
            tickTask = null;
        }
        if (announce) {
            broadcast(Component.text("Death Swap stopped.", NamedTextColor.RED));
        }
        participants.clear();
    }

    private void tick() {
        // Drop disconnected players; abort if too few remain.
        List<Player> alive = new ArrayList<>();
        for (UUID id : participants) {
            Player p = Bukkit.getPlayer(id);
            if (p != null && p.isOnline()) alive.add(p);
        }
        if (alive.size() < 2) {
            broadcast(Component.text("Not enough players online — Death Swap cancelled.",
                    NamedTextColor.DARK_RED));
            stop(false);
            return;
        }


        secondsLeft--;

        // Reminders
        if (secondsLeft == swapSeconds / 2) {
            announce("Halfway there — " + formatTime(secondsLeft) + " left until swap!",
                    NamedTextColor.YELLOW, Sound.BLOCK_NOTE_BLOCK_PLING);
        } else if (secondsLeft == 60 && swapSeconds > 60) {
            announce("1 minute until swap!", NamedTextColor.GOLD, Sound.BLOCK_NOTE_BLOCK_BELL);
        } else if (secondsLeft <= 10 && secondsLeft > 0) {
            announce(secondsLeft + "...", NamedTextColor.RED, Sound.BLOCK_NOTE_BLOCK_HAT);
        }

        if (secondsLeft <= 0) {
            List<Player> swappable = new ArrayList<>();
            for (Player p : alive) {
                if (p.getGameMode() != org.bukkit.GameMode.SPECTATOR) {
                    swappable.add(p);
                }
            }

            if (swappable.size() < 2) {
                broadcast(Component.text(
                        "Swap skipped — not enough non-spectator players.",
                        NamedTextColor.YELLOW));
            } else {
                doSwap(swappable);
            }
            secondsLeft = swapSeconds;
        }
    }


    private void doSwap(List<Player> alive) {
        List<Location> locs = new ArrayList<>();
        for (Player p : alive) locs.add(p.getLocation().clone());
        Collections.rotate(locs, -1);

        for (int i = 0; i < alive.size(); i++) {
            Player p = alive.get(i);
            p.teleport(locs.get(i));
            p.playSound(p.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1f);
        }

        broadcast(Component.text("SWAP!", NamedTextColor.LIGHT_PURPLE));
        for (Player p : alive) {
            p.showTitle(Title.title(
                    Component.text("SWAP!", NamedTextColor.LIGHT_PURPLE),
                    Component.text("Next swap in " + formatTime(swapSeconds), NamedTextColor.GRAY),
                    Title.Times.times(Duration.ofMillis(200), Duration.ofMillis(1500), Duration.ofMillis(400))
            ));
        }
    }

    private void announce(String msg, NamedTextColor color, Sound sound) {
        Component comp = Component.text(msg, color);
        for (UUID id : participants) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            p.sendMessage(comp);
            p.showTitle(Title.title(
                    Component.empty(),
                    comp,
                    Title.Times.times(Duration.ofMillis(100), Duration.ofMillis(800), Duration.ofMillis(200))
            ));
            p.playSound(p.getLocation(), sound, 1f, 1f);
        }
    }

    private void broadcast(Component msg) {
        Bukkit.getServer().sendMessage(msg);
    }

    private String formatTime(int seconds) {
        int m = seconds / 60;
        int s = seconds % 60;
        if (m == 0) return s + "s";
        return m + "m " + s + "s";
    }
}
