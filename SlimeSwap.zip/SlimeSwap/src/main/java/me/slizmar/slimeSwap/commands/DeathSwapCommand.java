package me.slizmar.slimeSwap.commands;

import me.slizmar.slimeSwap.SlimeSwap;
import me.slizmar.slimeSwap.game.GameManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.jetbrains.annotations.NotNull;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class DeathSwapCommand implements CommandExecutor, TabCompleter {

    private final SlimeSwap plugin;
    private final GameManager game;

    public DeathSwapCommand(SlimeSwap plugin, GameManager game) {
        this.plugin = plugin;
        this.game = game;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command cmd,
                             @NotNull String label, @NotNull String[] args) {

        if (!sender.isOp() && !sender.hasPermission("slimeswap.admin")) {
            sender.sendMessage(Component.text("You must be op to use this.", NamedTextColor.RED));
            return true;
        }

        if (args.length == 0) {
            sendUsage(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "settime" -> {
                if (args.length < 2) { sender.sendMessage("Usage: /deathswap settime <seconds>"); return true; }
                try {
                    int seconds = Integer.parseInt(args[1]);
                    if (!game.setSwapSeconds(seconds)) {
                        sender.sendMessage(Component.text("Time must be at least 10 seconds.", NamedTextColor.RED));
                    } else {
                        sender.sendMessage(Component.text("Swap interval set to " + seconds + "s.", NamedTextColor.GREEN));
                    }
                } catch (NumberFormatException e) {
                    sender.sendMessage(Component.text("Not a number: " + args[1], NamedTextColor.RED));
                }
            }
            case "setplayers" -> {
                if (args.length < 2) { sender.sendMessage("Usage: /deathswap setplayers <2|3|4>"); return true; }
                try {
                    int n = Integer.parseInt(args[1]);
                    if (!game.setPlayerCount(n)) {
                        sender.sendMessage(Component.text("Player count must be 2, 3, or 4.", NamedTextColor.RED));
                    } else {
                        sender.sendMessage(Component.text("Player count set to " + n + ".", NamedTextColor.GREEN));
                    }
                } catch (NumberFormatException e) {
                    sender.sendMessage(Component.text("Not a number: " + args[1], NamedTextColor.RED));
                }
            }
            case "start" -> {
                String err = game.start();
                if (err != null) sender.sendMessage(Component.text(err, NamedTextColor.RED));
            }
            case "stop" -> {
                if (!game.isRunning()) {
                    sender.sendMessage(Component.text("No game is running.", NamedTextColor.YELLOW));
                } else {
                    game.stop(true);
                }
            }
            case "status" -> {
                sender.sendMessage(Component.text(
                        "Running: " + game.isRunning()
                                + " | Players: " + game.getPlayerCount()
                                + " | Interval: " + game.getSwapSeconds() + "s",
                        NamedTextColor.AQUA));
            }
            default -> sendUsage(sender);
        }
        return true;
    }

    private void sendUsage(CommandSender s) {
        s.sendMessage(Component.text("SlimeSwap commands:", NamedTextColor.GOLD));
        s.sendMessage(Component.text("/deathswap settime <seconds>", NamedTextColor.GRAY));
        s.sendMessage(Component.text("/deathswap setplayers <2|3|4>", NamedTextColor.GRAY));
        s.sendMessage(Component.text("/deathswap start", NamedTextColor.GRAY));
        s.sendMessage(Component.text("/deathswap stop", NamedTextColor.GRAY));
        s.sendMessage(Component.text("/deathswap status", NamedTextColor.GRAY));
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                      @NotNull String alias, @NotNull String[] args) {
        if (args.length == 1) {
            return new ArrayList<>(Arrays.asList("settime", "setplayers", "start", "stop", "status"));
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("setplayers")) {
            return Arrays.asList("2", "3", "4");
        }
        return Collections.emptyList();
    }
}
