package me.slizmar.slimeSwap;

import me.slizmar.slimeSwap.commands.DeathSwapCommand;
import me.slizmar.slimeSwap.game.GameManager;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Objects;

public final class SlimeSwap extends JavaPlugin {

    private GameManager gameManager;

    @Override
    public void onEnable() {
        this.gameManager = new GameManager(this);
        Objects.requireNonNull(getCommand("deathswap"))
                .setExecutor(new DeathSwapCommand(this, gameManager));
        getLogger().info("SlimeSwap enabled. /deathswap to begin.");
    }

    @Override
    public void onDisable() {
        if (gameManager != null) {
            gameManager.stop(false);
        }
        getLogger().info("SlimeSwap disabled.");
    }

    public GameManager getGameManager() {
        return gameManager;
    }
}
